package temaPOO;

import java.util.ArrayList;
import java.util.List;

public interface Strategy {
    public void execute(Job job, User user);
}