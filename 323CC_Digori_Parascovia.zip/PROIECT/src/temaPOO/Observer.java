package temaPOO;

public interface Observer {
    public void update(Notification notification);
}
